using UnityEngine;

public class Cherry : Fruit
{
    public int GetFruit()
    {
        Debug.Log("Cherry Obtained");
        return 1;
    }
}
