using UnityEngine;

public class Grape : Fruit
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public int GetFruit()
    {
        Debug.Log("Grape Obtained");
        return 2;
    }
}
