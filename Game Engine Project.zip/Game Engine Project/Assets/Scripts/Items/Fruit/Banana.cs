using UnityEngine;

public class Banana : Fruit
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public int GetFruit()
    {
        Debug.Log("Banana Obtained");
        return 0;
    }

}
